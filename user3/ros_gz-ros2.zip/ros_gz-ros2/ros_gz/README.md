# ROS-Gazebo packages

`ros_gz` is a metapackage that installs all packages integrating
[ROS](http://www.ros.org/) and [Gazebo](https://gazebosim.org):
